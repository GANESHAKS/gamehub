
#include<GL/freeglut.h>
#define gena 0
#ifndef genb && genc
#include "general.h"
#endif // genb

void about();
void about_ui();
void about_printing();

void about_ui(){
   RgbColor color1,color2,color3;
    color1 =createColor(25, 25, 24, 0);
    color2 = createColor(25, 25,120 , 1);
    color3=createColor(30,30,33,1);


    ui(color1,color2,color3);
    glPushMatrix();
    color1 =createColor(25, 25,120 , 1);
    color2 = createColor(220, 120,120 , 1);
    draw_box(12,13,17,18,color1,color2);



//user functions

//drawing drawing sphere

   glPopMatrix();



}
void about_printing()
{
     char score_line[]="Score :";
     char str[100];

     drawText(" D E T A I L S ", -180, 300, 0,2);

     drawText(" Developers  : ", -525, 180, 0,2);
     drawText(" Name : Ganesha K S ", -400, 150, 0,0);
     drawText(" USN : 4MW17cs030 ", -400, 120, 0,0);
         drawText(" Name : Chethana mogaveer ", 0, 150, 0,0);
     drawText(" USN : 4MW17cs018 ", 0, 120, 0,0);
      drawText(" About Application  : ", -525, 0, 0,2);
       drawText(" This application is developed by GULTU group.This Application contains 2 games.", -400, -30, 0,5);
        drawText(" Copy right  : GULTU ", -550, -300, 0,4);
         drawText("Press F1 for Main Menu ", 0, -300, 0,4);

}





void about()
{

   glPushMatrix();

    about_ui();
    about_printing();

    glPopMatrix();



}
